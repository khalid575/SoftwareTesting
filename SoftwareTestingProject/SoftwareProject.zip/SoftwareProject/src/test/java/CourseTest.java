import static org.junit.Assert.*;
import org.junit.Test;

public class CourseTest {

    @Test
    public void testValidConstructor() {
        Course c = new Course("Math", 3, "A");
        assertEquals("Math", c.getCourseName());
        assertEquals(3, c.getCreditHours());
        assertEquals("A", c.getLetterGrade());
    }

    @Test
    public void testInvalidCourseName() {
        Course c = new Course("", 3, "B");
        assertEquals("Unknown", c.getCourseName());
    }

    @Test
    public void testInvalidCreditHoursLow() {
        Course c = new Course("Math", 0, "C");
        assertEquals(3, c.getCreditHours());
    }

    @Test
    public void testInvalidCreditHoursHigh() {
        Course c = new Course("Math", 10, "C");
        assertEquals(3, c.getCreditHours());
    }

    @Test
    public void testInvalidLetterGrade() {
        Course c = new Course("Math", 3, "Z");
        assertEquals("F", c.getLetterGrade());
    }

    @Test
    public void testGradePointA() {
        Course c = new Course("Math", 3, "A");
        assertEquals(4.0, c.getGradePoint(), 0.01);
    }

    @Test
    public void testGradePointF() {
        Course c = new Course("Math", 3, "F");
        assertEquals(0.0, c.getGradePoint(), 0.01);
    }
}
