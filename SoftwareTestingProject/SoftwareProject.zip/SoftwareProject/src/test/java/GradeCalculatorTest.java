import static org.junit.Assert.*;
import org.junit.Test;

public class GradeCalculatorTest {

    GradeCalculator gc = new GradeCalculator();

    @Test
    public void testInvalidLow() {
        assertEquals("Invalid", gc.calculateLetterGrade(-1));
    }

    @Test
    public void testInvalidHigh() {
        assertEquals("Invalid", gc.calculateLetterGrade(120));
    }

    @Test
    public void testGradeA() {
        assertEquals("A", gc.calculateLetterGrade(95));
    }

    @Test
    public void testGradeB() {
        assertEquals("B", gc.calculateLetterGrade(85));
    }

    @Test
    public void testBoundary90() {
        assertEquals("A", gc.calculateLetterGrade(90));
    }

    @Test
    public void testBoundary80() {
        assertEquals("B", gc.calculateLetterGrade(80));
    }

    @Test
    public void testBoundary70() {
        assertEquals("C", gc.calculateLetterGrade(70));
    }
}
