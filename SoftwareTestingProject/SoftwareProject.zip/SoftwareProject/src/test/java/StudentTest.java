import static org.junit.Assert.*;
import org.junit.Test;

public class StudentTest {

    @Test
    public void testConstructorValid() {
        Student s = new Student("123", "Ali");
        assertEquals("123", s.getId());
        assertEquals("Ali", s.getName());
    }

    @Test
    public void testConstructorInvalidName() {
        Student s = new Student("123", "");
        assertEquals("Unknown", s.getName());
    }

    @Test
    public void testEnrollCourse() {
        Student s = new Student("1", "A");
        Course c = new Course("Math", 3, "A");
        s.enrollCourse(c);
        assertEquals(1, s.getCourses().size());
    }

    @Test
    public void testGPAEmpty() {
        Student s = new Student("1", "A");
        assertEquals(0.0, s.calculateGPA(), 0.01);
    }

    @Test
    public void testGPAValid() {
        Student s = new Student("1", "A");
        s.enrollCourse(new Course("Math", 3, "A"));
        s.enrollCourse(new Course("CS", 3, "B"));
        assertEquals(3.5, s.calculateGPA(), 0.01);
    }
}
